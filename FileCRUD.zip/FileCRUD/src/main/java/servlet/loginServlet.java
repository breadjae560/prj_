package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();

		String id = request.getParameter("id");
		String pw = request.getParameter("pw");

		String adminId = "admin";
		String adminPw = "1234";

		if (id.equals(adminId)) {
			if (pw.equals(adminPw))
				System.out.println("로그인 성공");
				response.sendRedirect("/webhard.jsp");
				
				
		} else
			System.out.println("로그인 실패");
			response.sendRedirect("/webhard.jsp");
			

	}

}
