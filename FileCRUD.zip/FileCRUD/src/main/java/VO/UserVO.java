package VO;

public class UserVO {
	String name;
	String id;
	String pw;
	String email;
}
