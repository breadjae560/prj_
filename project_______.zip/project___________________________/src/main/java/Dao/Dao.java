package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import VO.MemberVO;



public class Dao {
	Connection con = null;

	public Connection DB_Con() {
		String url = "jdbc:oracle:thin:@localhost:1521/xe";
		String uid = "system";
		String upw = "1234";

		try {
			Class.forName("oracle.jdbc.OracleDriver");
			con = DriverManager.getConnection(url, uid, upw);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	// ? = VO 따로 준비해주세요.
	public ArrayList<MemberVO> select(String query) {
		con = DB_Con();
		ResultSet rs = null;
		MemberVO mv = new MemberVO();
		ArrayList<MemberVO> list = new ArrayList<MemberVO>();

		try {

			Statement stmt = con.createStatement();

			rs = stmt.executeQuery(query);

			while (rs.next()) {
				
				mv.setId(rs.getString("id"));
				mv.setPw(rs.getString("pw"));
				mv.setName(rs.getString("name"));
				mv.setEmail(rs.getString("email"));
				mv.setTel(rs.getString("tel"));
				list.add(mv);
				break;
				
			}

			for (MemberVO m : list) {

				//System.out.println(m.getTitle());
				//System.out.println(m.getPrice());

			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		return list;

	}

	public void insert(String query) {

		con = DB_Con();

		try {

			PreparedStatement pstmt = con.prepareStatement(query);
			int rs = pstmt.executeUpdate();

			if (rs == 1) {
				System.out.println("DB 저장 성공");
			} else {
				System.out.println("DB 저장 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void update(String query) {

		con = DB_Con();

		try {

			PreparedStatement pstmt = con.prepareStatement(query);
			int rs = pstmt.executeUpdate();

			if (rs == 1) {
				System.out.println("DB 저장 성공");
			} else {
				System.out.println("DB 저장 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void delete(String query) {

		con = DB_Con();

		try {

			PreparedStatement pstmt = con.prepareStatement(query);
			int rs = pstmt.executeUpdate();

			if (rs == 1) {
				System.out.println("DB 저장 성공");
			} else {
				System.out.println("DB 저장 실패");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
