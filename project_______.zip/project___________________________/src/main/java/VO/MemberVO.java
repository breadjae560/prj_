package VO;

import lombok.Data;

@Data
public class MemberVO {
	String id;
	String pw;
	String name;
	String email;
	String tel;	
}
