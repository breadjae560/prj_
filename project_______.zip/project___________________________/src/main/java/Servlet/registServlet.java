package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.Dao;

@WebServlet("/registServlet")
public class registServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		Dao dao = new Dao();
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String tel = request.getParameter("tel");
		
		// 회원가입 제약사항에 이상 없으면 true를 돌립니다.
		// if(true) {}
		
		String query = "INSERT INTO MEMBER VALUES('"+ id +"','"+ pw +"', '"+ name +"','"+ email +"',"+ tel +")";
		
		dao.insert(query);
		System.out.println(query);
		
		
		if(id != null) {
			out.print("<script>alert('"+ name +"님 회원가입을 축하합니다!')</script>");
			response.sendRedirect("home.jsp");
		}else {
			out.print("<script>alert('회원가입에 실패하였습니다.')</script>");
			response.sendRedirect("regist.jsp");
		}
		
		
	}

}
