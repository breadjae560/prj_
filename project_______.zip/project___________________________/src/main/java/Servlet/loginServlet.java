package Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.Dao;

@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		Dao dao = new Dao();
		String query = null;
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		String admin_id = "admin";
		String admin_pw = "1234";
		
		//( ---- DB 영역 
		/*
			query = "SELECT id FROM MEMBER";
			dao.select(query);
			query = "SELECT pw FROM MEMBER";
			dao.select(query);
		*/
		//  ---- )
		
		if(id.equals(admin_id) && pw.equals(admin_pw)) {
			
			HttpSession session = request.getSession();
			session.setAttribute("id", id);
			session.setAttribute("pw", pw);
			out.print("<script>alert('로그인 성공!')</script>");
			response.sendRedirect("home.jsp");
			
		}else {
			out.print("<script>alert('아이디 또는 비밀번호가 틀렸습니다!')</script>");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
	}

}
